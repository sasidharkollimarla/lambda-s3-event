
def lambda_handler(event, context):
    print('I am triggered v3.0')
    return 'python lambda'

